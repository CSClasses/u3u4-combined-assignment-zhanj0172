//
//  ViewController.swift
//  Unit 3 & 4 Q4
//
//  Created by Jiahao Zhang on 2019-05-13.
//  Copyright © 2019 Jiahao Zhang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // These are five buttons: four arrows and reset button
    @IBOutlet weak var arrowPanel: UIView!
    @IBOutlet weak var resetBtn: UIButton!
    @IBOutlet weak var upBtn: UIButton!
    @IBOutlet weak var downBtn: UIButton!
    @IBOutlet weak var leftBtn: UIButton!
    @IBOutlet weak var rightBtn: UIButton!
    
    // This is a cover to hide the top picture and make animation later
    @IBOutlet weak var topCover: UIView!
    
    // These are question image and questions panel
    @IBOutlet weak var questionImg: UIImageView!
    @IBOutlet weak var questions: UIView!
    
    // these are questions and answer fields
    @IBOutlet weak var question1: UITextField!
    @IBOutlet weak var question2: UISwitch!
    @IBOutlet weak var submitbtn: UIButton!
    
    // A variable indicating the states of the app
    var panelDirection: Int  = 0 {
        // didSet function would set arrow panel to original state, similar to reset, then make animation on [direction]Pressed function
        didSet {
            switch oldValue {
            case 1:
                self.arrowPanel.center.y -= 50
                self.topCover.center.y -= 230
            case 2:
                self.arrowPanel.center.y += 50
                questionImg.isHidden = true
                questions.isHidden = true
            case 3:
                self.arrowPanel.center.x -= 50
            case 4:
                self.arrowPanel.center.x += 50
            default:
                break
            }
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // add right swipe mathod to allow swipe between question images and question-answer form
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture(_:)))
        swipeRight.direction = .right
        view.addGestureRecognizer(swipeRight)
        
        // add left swipe mathod to allow swipe between question images and question-answer form
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture(_:)))
        swipeLeft.direction = .left
        view.addGestureRecognizer(swipeLeft)
        
        // Add a toolbar with done button on keybord when inputing
        let editToolbar = UIToolbar()
        editToolbar.sizeToFit()
        
        // The done button in keyboard toolbar
        let doneButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.done, target: self, action: #selector(self.donePressed))
        editToolbar.setItems([doneButton], animated: false)
        
        // add the toolbar to questions' input field keyboard
        question1.inputAccessoryView = editToolbar
    }
    
    // Handler when press up arrow
    @IBAction func upPressed(_ sender: UIButton) {
        // set state to up
        self.panelDirection = 1
        // Add moving down animation
        UIView.animate(withDuration: 1) {
            self.arrowPanel.center.y += 50
            self.topCover.center.y += 230
        }
    }
    
    // Handler when press dowm arrow
    @IBAction func downPressed(_ sender: UIButton) {
        self.panelDirection = 2
        UIView.animate(withDuration: 1) {
            self.arrowPanel.center.y -= 50
        }
        
        // show the question image and hide the question after arrow moving animation done
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
            self.questionImg.isHidden = false
            self.questions.isHidden = true
        })
    }
    
    // handler of left arrow, it should change to previours question, now it would popup a dialog to show the message that indicating on tfirst question
    @IBAction func leftPressed(_ sender: UIButton) {
        self.panelDirection = 3
        UIView.animate(withDuration: 1) {
            self.arrowPanel.center.x += 50
        }
        
        // codes to show up dialog box with a done button
        let alert = UIAlertController(title: "Message", message: "It is on the first question, press down arrow to answer", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Done", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
    // Handler of right arrow, it would go to next question, but now it is similar to left arrow handler
    @IBAction func rightPressed(_ sender: UIButton) {
        self.panelDirection = 4
        UIView.animate(withDuration: 1) {
            self.arrowPanel.center.x -= 50
        }
        
        let alert = UIAlertController(title: "Message", message: "More Questions will come.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Done", style: .cancel, handler: nil))
        self.present(alert, animated: true)
    }
    
    // A reset button, reset the app to original state
    @IBAction func resetPressed(_ sender: UIButton) {
        self.panelDirection = 0
        question1.text = ""
    }
    
    // this is the actual handler of swipe gesture that setup on viewDidLoad (left and right swipe)
    @objc func respondToSwipeGesture(_ sender: UISwipeGestureRecognizer) {
        // Make sure the down arrow is pressed so it is in answering state
        if panelDirection != 2 {
            return
        }
        
        // toggle between the question image and the questions-answer form
        if questionImg.isHidden == true {
            questionImg.isHidden = false
            questions.isHidden = true
        } else {
            questionImg.isHidden = true
            questions.isHidden = false
        }
    }
    
    // this is the handler of done button the keyboard toolbar, actually it is used to hide the keyboard
    @objc func donePressed() {
        view.endEditing(true)
    }
    
    // the handler when submit button on the question-answer form pressed
    @IBAction func submitPressed(_ sender: UIButton) {
        // check the answer if they are right, if correct, popup a congratulate dialog box
        if question1.text == "8" && question2.isOn == false {
            let alert = UIAlertController(title: "Your result", message: "All right, Good job.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Done", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        } else {
            // Unforturn the answer are now all right, popup a "Try again" dialog box
            let alert = UIAlertController(title: "Your result", message: "Try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Done", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
    }
    
}

