/*
 * Unit 1 Assignment 1 Question 1
 * Jiahao Zhang
 * May 20
 * All done by myself
 *
 */

 //import all the classes needed
import java.awt.BorderLayout;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

//public class Mainframe
public class MainFrame extends JFrame {

	private static final long serialVersionUID = 1L;

	public String jarPath;

	private JComboBox provCB;

	private JComboBox stnCB;

	private Map dataMap;

	private Map provMap;

	private JTextArea result;

	private JLabel summary;

	private JButton details;

	{
		jarPath = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
		jarPath = java.net.URLDecoder.decode(jarPath, "UTF-8");
		File file = new File(jarPath);
		jarPath = file.getParent() + File.separator;
	}

	//set up the mainFrame basic settings
	public MainFrame() throws Exception {
		super();
		this.setTitle("Weather Query");
		setResizable(false);
		int x = this.getToolkit().getScreenSize().width - 615;
		int y = this.getToolkit().getScreenSize().height - 500;
		setBounds(x / 2, y / 2, 615, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//set up a new JPanel
		final JPanel panel = new JPanel();
		panel.setToolTipText("");
		panel.setBackground(Color.WHITE);
		panel.setLayout(null);
		getContentPane().add(panel, BorderLayout.CENTER);


		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 610, 80);
		panel_1.setLayout(null);
		panel_1.setBorder(new TitledBorder(null, null,
				TitledBorder.DEFAULT_JUSTIFICATION,
				TitledBorder.DEFAULT_POSITION, null, Color.BLUE));
		panel.add(panel_1);


		JLabel prov = new JLabel("Province:");
		prov.setBounds(18, 25, 66, 15);
		panel_1.add(prov);

		JLabel stn = new JLabel("Station Name:");
		stn.setBounds(160, 25, 126, 15);
		panel_1.add(stn);

		//use JComboBox to show the available options (province)
		provCB = new JComboBox();
		provCB.setBounds(90, 25, 60, 21);
		provCB.addItem("");
		provCB.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED){
					provCBChanged((String)provCB.getSelectedItem());
				}
			}
		});
		panel_1.add(provCB);

		//use JComboBox to show the available options (Station)
		stnCB = new JComboBox();
		stnCB.setBounds(250, 25, 350, 21);
		panel_1.add(stnCB);

		//JButton was used to perform the
		JButton button_1 = new JButton("Query");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				query();
			}
		});
		button_1.setBounds(530, 55, 70, 20);
		panel_1.add(button_1);

		summary = new JLabel("");
		summary.setBounds(18, 100, 450, 50);
		panel.add(summary);

		//Button Details as listener to show the detailed information that the use choose
		details = new JButton("details");
		details.setBounds(480, 116, 80, 20);
		details.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(result.isVisible()){
					result.setVisible(false);
				}else{
					result.setVisible(true);
				}
			}
		});
		panel.add(details);

		result = new JTextArea();
		result.setBounds(18, 170, 500, 500);
		result.setEditable(false);
		panel.add(result);

		details.setVisible(false);
		result.setVisible(false);

		readCsv();
	}

	//The following method is used to read CSV files
	private void readCsv() throws Exception {
		String fileName = "eng-climate-summaries-All-4,2018.csv";
		BufferedReader br = new BufferedReader(new FileReader(jarPath + fileName));
		String line = br.readLine();
		dataMap = new HashMap();
		provMap = new HashMap();
		while((line = br.readLine()) != null){
			Map map = new HashMap();
			String[] rows = line.split(",");
			map.put("Stn_Name", rows[0]);
			map.put("Lat", rows[1]);
			map.put("Long", rows[2]);
			map.put("Prov", rows[3]);
			map.put("Tm", rows[4]);
			map.put("DwTm", rows[5]);
			map.put("D", rows[6]);
			map.put("Tx", rows[7]);
			map.put("DwTx", rows[8]);
			map.put("Tn", rows[9]);
			map.put("DwTn", rows[10]);
			map.put("S", rows[11]);
			map.put("DwS", rows[12]);
			map.put("S%N", rows[13]);
			map.put("P", rows[14]);
			map.put("DwP", rows[15]);
			map.put("P%N", rows[16]);
			map.put("S_G", rows[17]);
			map.put("Pd", rows[18]);
			map.put("BS", rows[19]);
			map.put("DwBS", rows[20]);
			map.put("BS%", rows[21]);
			map.put("HDD", rows[22]);
			map.put("CDD", rows[23]);
			map.put("Clim_ID", rows[24]);

			//store all the elements into the list
			List <String> subList = null;
			if(provMap.get(rows[3]) != null){
				subList = (List)provMap.get(rows[3]);
			} else {
				subList = new ArrayList();
			}
			dataMap.put(rows[0] + "(" + rows[1] + "," + rows[2] + ")" , map);
			subList.add(rows[0] + "(" + rows[1] + "," + rows[2] + ")");
			provMap.put(rows[3], subList);
		}
		br.close();


		Iterator it = provMap.keySet().iterator();
		while(it.hasNext()){
			String key = (String) it.next();
			provCB.addItem(key);
		}
	}

	private void provCBChanged(String item) {
		stnCB.removeAllItems();
		if("".equals(item)){
			return;
		}
		List <String> subList = (List) provMap.get(item);
		for(int i = 0; i < subList.size(); i++){
			stnCB.addItem(subList.get(i));
		}
	}

	//query method to check if stnCB is null
	private void query() {
		if(stnCB.getSelectedItem() == null){
			details.setVisible(false);
			result.setText("");
			summary.setText("");
			return;
		}
		Map data = (Map) dataMap.get(stnCB.getSelectedItem());

		StringBuffer sb = new StringBuffer();
		Iterator it = data.keySet().iterator();
		int i = 1;
		while(it.hasNext()){
			String key = (String) it.next();
			sb.append(key).append(" : ").append(data.get(key)).append("           ");
			if(i++ % 3 == 0){
				sb.append("\n");
			}
		}

		//StringBuffer to get the detailed information
		StringBuffer summarySb = new StringBuffer();
		summarySb.append("Temperature (°C) : ").append(data.get("Tm")).append("     ");
		summarySb.append("Snowfall (cm) : ").append(data.get("S")).append("     ");
		summarySb.append("Total Precipitation (mm) : ").append(data.get("P")).append("     ");
		summary.setText(summarySb.toString());
		result.setText(sb.toString());

		details.setVisible(true);
	}

	//main method
	public static void main(String args[]) {
		try {
			MainFrame frame = new MainFrame();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
