
/*
 * Unit 3 Assignment 1 Question 2
 * Jiahao Zhang
 * May 20
 * All done by myself
 *
 */

import Foundation

//define all variables
var allInt : [Int] = []
var allDouble : [Double] = []
var positiveInt : [Int] = []
var positiveDouble : [Double] = []
var negative : [String] = []

//print instructions
print("This program can help sort a series of numbers into positive integers, positive doubles and all negative numbers.")
print("Please type in a series of numbers spliting by \" \"(space), after typing in all the numbers you want, press enter to sort them out.")


if let user = readLine(){
  //get the user input and separate and store them in a big array
  var arr = user.components(separatedBy:" ")
  print(arr)
  //print(arr.count)
  for i in 0...(arr.count-1){
    //print(arr[i])
    //if can be converted to int, then it is an integer
    if let n = Int(arr[i]){
      allInt.append(n)
      //print(allInt)
    }

    //else will be stored in a array that contains doubles
    else if let d = Double(arr[i]){
      allDouble.append(d)
      print(allDouble)
    }

    //error message in case any illegal input
    else {
      print("Please type in NUMBERS ONLY! ")
      break
    }
    //let k = Int(arr[i]) ?? 0
  }

  for i in 0...(allInt.count-1){
    //tell if the integer is positive or negative
    if (allInt[i]>0){
      //positive integers will be stored in another positive array
      positiveInt.append(allInt[i])
    }
    else {
      //negative integers will be stored in the big negative array
      negative.append(String(allInt[i]))
      }
    }
  
  //same operations as integers
  for i in 0...(allDouble.count-1){
    if (allDouble[i]>0){
      positiveDouble.append(allDouble[i])
    }
    else {
        negative.append(String(allDouble[i]))
      }
    }

  //special case : 0
  let zero = "0"
  while negative.contains("0"){
    if let zeroIndex = negative.firstIndex(of:zero){
      negative.remove(at:zeroIndex)
    }
  }

  //output
  print("positve int:")
  print(positiveInt)
  print("")
  print("positive double:")
  print(positiveDouble)
  print("")
  print("negative:")
  print(negative)

}



/*
let str = "Andrew, Ben, John, Paul, Peter, Laura"
let array = str.components(separatedBy: ",")
print (array)
*/